function bands = getBands()
%GETBANDS Zwraca tablicę struktur z definicjami pasm pomiarowych
%   wg DOCX (EMC_tabele_wyniki_QP_od_150kHz_..._.docx).
%
%   Pole każdej struktury:
%       id       - identyfikator pasma (3..10)
%       fStartHz - dolna częstotliwość zakresu [Hz]
%       fStopHz  - górna częstotliwość zakresu [Hz]
%       fieldType- 'H' (pole magnetyczne) lub 'E' (pole elektryczne)
%       hasPolarization - true gdy E ma polaryzację V/H (pasma 7..10)
%
%   Konwencja nazw plików (z DOCX):
%       Pasmo 3: 0,15-1,15 MHz, antena HFH2-Z2 (pętlowa, pole H)
%       Pasmo 4: 1-11 MHz,    antena HFH2-Z2
%       Pasmo 5: 10-20 MHz,   antena HFH2-Z2
%       Pasmo 6: 20-30 MHz,   antena HFH2-Z2
%       Pasmo 7: 30-230 MHz,  antena HK116 (V i H)
%       Pasmo 8: 200-300 MHz, antena HK116 (V i H)
%       Pasmo 9: 300-500 MHz, antena HL223 (V i H)
%       Pasmo 10: 500-1000 MHz, antena HL223 (V i H)

    bands = struct( ...
        'id',              {3,         4,         5,          6,          7,           8,           9,            10}, ...
        'fStartHz',        {150e3,     1e6,       10e6,       20e6,       30e6,        200e6,       300e6,        500e6}, ...
        'fStopHz',         {1.15e6,    11e6,      20e6,       30e6,       230e6,       300e6,       500e6,        1000e6}, ...
        'fieldType',       {'H',       'H',       'H',        'H',        'E',         'E',         'E',          'E'}, ...
        'hasPolarization', {false,     false,     false,      false,      true,        true,        true,         true});
end
