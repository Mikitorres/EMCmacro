function limitDb = computeLimit(fHz, fieldType, condition, variant)
%COMPUTELIMIT Oblicza limit zaburzeń promieniowanych wg PN-EN 50121-3-1.
%
%   limitDb = computeLimit(fHz, fieldType, condition, variant)
%
%   Wejście:
%       fHz       - wektor częstotliwości [Hz]
%       fieldType - 'H' (pole magnetyczne, dB?A/m) lub 'E' (pole elektryczne, dB?V/m)
%       condition - 'jazda' lub 'postoj' (warunek pomiaru)
%       variant   - 'B' (domyślny - kolejowy), 'C', 'Tramwaj', 'Wagon'
%
%   Wyjście:
%       limitDb   - wektor limitu w dB, dopasowany rozmiarem do fHz
%                   (NaN poza zakresem objętym limitem)
%
%   Wartości wyjściowe odpowiadają poziomom punktów łamanych z arkusza
%   'Limits' w pliku EMC_MAKRO_WZOR_wer_16_PL.xlsm. Pomiędzy punktami
%   limit jest interpolowany liniowo na osi log10(f).
%   Przykład (Limity B, pole H, jazda):
%       9 kHz  -> 60 dB?A/m
%       150 kHz -> 35 dB?A/m  (zakres 9..150 kHz)
%       150 kHz -> 65 dB?A/m  (zakres 150 kHz..30 MHz)
%       30 MHz  -> 15 dB?A/m
%   Pole E zaczyna się od 30 MHz i kończy na 1 GHz.

    if nargin < 4 || isempty(variant)
        variant = 'B';
    end
    if nargin < 3 || isempty(condition)
        condition = 'jazda';
    end

    % Pobierz punkty łamane (breakpoints) dla danego wariantu/pola/warunku
    [fkHzPts, lvlPts] = getBreakpoints(variant, fieldType, condition);

    % Częstotliwości wejściowe -> kHz (norma definiuje limity w kHz)
    fkHz = fHz(:) / 1000;

    limitDb = nan(size(fkHz));
    if isempty(fkHzPts)
        return;
    end

    % Pasma są zdefiniowane parami (punkt początkowy i końcowy każdego segmentu).
    % Każda kolejna para (i, i+1) to jeden segment liniowy w skali log.
    % Przejście "skokowe" jest zakodowane jako dwa punkty o tej samej f
    % z różnymi poziomami (np. 150 kHz: 35 -> 65).
    for s = 1:2:length(fkHzPts)-1
        f1 = fkHzPts(s);
        f2 = fkHzPts(s+1);
        l1 = lvlPts(s);
        l2 = lvlPts(s+1);

        % Maska punktów wejściowych w tym segmencie (włącznie z brzegami)
        maskSeg = fkHz >= f1 & fkHz <= f2;
        if ~any(maskSeg)
            continue;
        end
        if f1 == f2
            % Segment punktowy - pomijamy (limit ustawi sąsiedni segment)
            continue;
        end
        % Interpolacja liniowa w skali log10(f):
        %   limit(f) = a*log10(f_kHz) + b   (jak w arkuszu Limits)
        a = (l2 - l1) / (log10(f2) - log10(f1));
        b = l1 - a*log10(f1);
        limitDb(maskSeg) = a*log10(fkHz(maskSeg)) + b;
    end
end


function [fkHzPts, lvlPts] = getBreakpoints(variant, fieldType, condition)
%GETBREAKPOINTS Zwraca punkty łamane definiujące limit z normy.
%   Wartości pochodzą z arkusza 'Limits' w pliku wzorcowym
%   EMC_MAKRO_WZOR_wer_16_PL.xlsm (kolumny B-F).

    fieldType = upper(fieldType);
    condition = lower(condition);
    variant   = upper(variant);

    fkHzPts = [];
    lvlPts  = [];

    switch variant
        case 'B'        % LIMITY B (kolejowy, podstawowy wg PN-EN 50121)
            if fieldType == 'H'
                if strcmp(condition, 'jazda')
                    fkHzPts = [9, 150, 150, 30000];
                    lvlPts  = [60, 35, 65, 15];
                else  % postoj
                    fkHzPts = [9, 150, 150, 30000];
                    lvlPts  = [50, 25, 55,  5];
                end
            else  % E
                if strcmp(condition, 'jazda')
                    fkHzPts = [30000, 1000000];
                    lvlPts  = [85, 60];
                else
                    fkHzPts = [30000, 1000000];
                    lvlPts  = [60, 50];
                end
            end

        case 'C'        % LIMITY C
            if fieldType == 'H'
                if strcmp(condition, 'jazda')
                    fkHzPts = [9, 150, 150, 30000];
                    lvlPts  = [50, 25, 55,  5];
                else
                    fkHzPts = [9, 150, 150, 30000];
                    lvlPts  = [50, 25, 55,  5];
                end
            else  % E
                if strcmp(condition, 'jazda')
                    fkHzPts = [30000, 1000000];
                    lvlPts  = [75, 50];
                else
                    fkHzPts = [30000, 1000000];
                    lvlPts  = [60, 50];
                end
            end

        case {'TRAMWAJ', 'TRAM'}
            if fieldType == 'H'
                if strcmp(condition, 'jazda')
                    fkHzPts = [9, 150, 150, 30000];
                    lvlPts  = [50, 25, 55,  5];
                else
                    fkHzPts = [9, 150, 150, 30000];
                    lvlPts  = [40, 15, 40, -5];
                end
            else
                if strcmp(condition, 'jazda')
                    fkHzPts = [30000, 1000000];
                    lvlPts  = [75, 50];
                else
                    fkHzPts = [30000, 1000000];
                    lvlPts  = [50, 50];
                end
            end

        case 'WAGON'
            % W arkuszu Limits Wagon ma podane tylko wartości "postoj" dla H
            % oraz "postoj" dla E. Używamy tych samych dla obu warunków.
            if fieldType == 'H'
                fkHzPts = [9, 150, 150, 30000];
                lvlPts  = [50, 25, 55,  5];
            else
                fkHzPts = [30000, 1000000];
                lvlPts  = [60, 50];
            end

        otherwise
            error('computeLimit:badVariant', ...
                'Nieznany wariant limitu: %s. Dozwolone: B, C, Tramwaj, Wagon.', variant);
    end
end
