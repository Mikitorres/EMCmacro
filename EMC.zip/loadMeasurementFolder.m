function dataset = loadMeasurementFolder(folder)
%LOADMEASUREMENTFOLDER Wczytuje wszystkie pliki pomiarowe z folderu i grupuje
%   je wg konwencji nazw zgodnej z DOCX (EMC_tabele_wyniki_QP_od_150kHz_...).
%
%   dataset = loadMeasurementFolder(folder) zwraca strukturę:
%
%   dataset.bands(k) - dla każdego pasma id 3..10 struktura z polami:
%       id           - 3..10
%       fStartHz, fStopHz, fieldType, hasPolarization (z getBands)
%       % Pola pomiarowe (struktury z .freq i .value, lub puste []):
%       jazda        - jazda MAXHOLD (np. plik 'J3' lub 'JV7'/'JH7')
%       jazdaH       - polaryzacja H (pasma 7..10), np. 'JH7'
%       jazdaV       - polaryzacja V (pasma 7..10), np. 'JV7'
%       hamowanie    - hamowanie MAXHOLD (np. 'J3B' lub 'JV7B'/'JH7B')
%       hamowanieH   - polaryzacja H
%       hamowanieV   - polaryzacja V
%       postoj       - postój QP (np. 'P3Q' lub 'PV7Q'/'PH7Q')
%       postojH, postojV
%       tloPrzed     - tło przed (jazda) MAXHOLD - 'T30'/'TV70'/'TH70'
%       tloPo        - tło po (jazda)  MAXHOLD - 'T31'/'TV71'/'TH71'
%       tloPrzedQP   - tło przed (postój) QP - 'T30Q'
%       tloPoQP      - tło po (postój) QP   - 'T31Q'
%       tloPrzedH, tloPrzedV, tloPoH, tloPoV (pasma 7..10)
%       tloPrzedHQ, tloPrzedVQ, tloPoHQ, tloPoVQ
%
%   dataset.folder      - ścieżka folderu
%   dataset.filesFound  - lista wszystkich rozpoznanych plików
%   dataset.filesSkipped- lista plików, których nie rozpoznano

    if ~isfolder(folder)
        error('loadMeasurementFolder:notAFolder', ...
            'Podana ścieżka nie jest folderem: %s', folder);
    end

    bands = getBands();
    nBands = numel(bands);

    % Pola, które chcemy mieć w każdej strukturze pasma
    template = struct( ...
        'id', [], ...
        'fStartHz', [], 'fStopHz', [], 'fieldType', '', 'hasPolarization', false, ...
        'jazda', [],     'jazdaH',     [], 'jazdaV',     [], ...
        'hamowanie', [], 'hamowanieH', [], 'hamowanieV', [], ...
        'postoj', [],    'postojH',    [], 'postojV',    [], ...
        'tloPrzed',  [], 'tloPrzedH',  [], 'tloPrzedV',  [], ...
        'tloPo',     [], 'tloPoH',     [], 'tloPoV',     [], ...
        'tloPrzedQP',[], 'tloPrzedHQ', [], 'tloPrzedVQ', [], ...
        'tloPoQP',   [], 'tloPoHQ',    [], 'tloPoVQ',    []);

    bandData = repmat(template, 1, nBands);
    for k = 1:nBands
        bandData(k).id              = bands(k).id;
        bandData(k).fStartHz        = bands(k).fStartHz;
        bandData(k).fStopHz         = bands(k).fStopHz;
        bandData(k).fieldType       = bands(k).fieldType;
        bandData(k).hasPolarization = bands(k).hasPolarization;
    end

    % Skanuj wszystkie pliki w folderze (nieukryte)
    dirInfo = dir(folder);
    dirInfo = dirInfo(~[dirInfo.isdir]);

    filesFound   = {};
    filesSkipped = {};

    for k = 1:numel(dirInfo)
        name = dirInfo(k).name;
        if startsWith(name, '.')
            continue;
        end
        % Pomiń typowe pliki nieinteresujące
        [~,~,ext] = fileparts(name);
        if any(strcmpi(ext, {'.xlsx', '.xlsm', '.docx', '.pdf', '.png', '.jpg', '.txt', '.mat'}))
            continue;
        end

        baseName = regexprep(name, '\.[^.]+$', '');  % usuń rozszerzenie
        info = parseFileName(baseName);
        if isempty(info)
            filesSkipped{end+1} = name; %#ok<AGROW>
            continue;
        end

        % Wczytaj plik
        try
            d = readESPI(fullfile(folder, name));
        catch ME
            warning('loadMeasurementFolder:readFailed', ...
                'Nie udało się wczytać %s: %s', name, ME.message);
            filesSkipped{end+1} = name; %#ok<AGROW>
            continue;
        end

        % Znajdź pasmo
        bandIdx = find([bandData.id] == info.bandId, 1);
        if isempty(bandIdx)
            filesSkipped{end+1} = name; %#ok<AGROW>
            continue;
        end

        % Przypisz do odpowiedniego pola
        bandData(bandIdx).(info.targetField) = d;
        filesFound{end+1} = sprintf('%s -> band %d, %s', name, info.bandId, info.targetField); %#ok<AGROW>
    end

    dataset = struct();
    dataset.folder       = folder;
    dataset.bands        = bandData;
    dataset.filesFound   = filesFound;
    dataset.filesSkipped = filesSkipped;
end


function info = parseFileName(name)
%PARSEFILENAME Rozpoznaje konwencję nazw z DOCX i zwraca info.bandId
%   oraz info.targetField (nazwę pola w strukturze pasma).
%
%   Reguły (z DOCX, sekcja "Uwagi do tabeli"):
%     T = tło, P = postój, J = jazda, B = hamowanie
%     V = antena pionowa (E), H = antena pozioma (E)
%     Q = pomiar z detektorem QuasiPeak
%
%   Przykłady:
%     T30   -> tło przed, MAXHOLD, pasmo 3 (drugie '0' = przed jazdą)
%     T31   -> tło po, MAXHOLD, pasmo 3 (drugie '1' = po jeździe)
%     T30Q  -> tło przed, QP, pasmo 3
%     T31Q  -> tło po, QP, pasmo 3
%     J3    -> jazda, pasmo 3
%     J3B   -> hamowanie, pasmo 3
%     P3Q   -> postój QP, pasmo 3
%     TV70  -> tło przed (V) MAXHOLD, pasmo 7
%     TV71Q -> tło po (V) QP, pasmo 7
%     TH100 -> tło przed (H) MAXHOLD, pasmo 10
%     JV7   -> jazda V, pasmo 7
%     JV7B  -> hamowanie V, pasmo 7
%     PH8Q  -> postój H QP, pasmo 8

    info = [];
    name = upper(strtrim(name));
    if isempty(name)
        return;
    end

    % Czy nazwa kończy się na 'Q' (oznaczenie QuasiPeak)?
    endsQ = endsWith(name, 'Q');
    if endsQ
        name = name(1:end-1);
    end

    % Czy nazwa kończy się na 'B' (hamowanie - tylko dla J)?
    endsB = false;
    if startsWith(name, 'J') && endsWith(name, 'B')
        endsB = true;
        name = name(1:end-1);
    end

    if length(name) < 2
        return;
    end

    typeChar = name(1);            % T / P / J
    rest = name(2:end);

    % Czy jest oznaczenie polaryzacji V/H jako drugi znak (pasma 7..10)?
    polChar = '';
    if rest(1) == 'V' || rest(1) == 'H'
        polChar = rest(1);
        rest = rest(2:end);
    end

    if isempty(rest)
        return;
    end

    % Określ pasmo i (dla T) wariant przed/po na podstawie cyfr
    bandId = NaN;
    isPre  = true;   % "przed" - dla T (gdy bez polaryzacji: T30, T40, ...)
    if isempty(polChar)
        % Pasma 3..6: nazwa to T<bandId><suffix> (suffix 0=przed, 1=po) dla T,
        % lub J/P + bandId
        if typeChar == 'T'
            % Cyfry: pasmo + suffix (0/1)
            % np. T30 -> band 3, suffix 0
            % np. T61 -> band 6, suffix 1
            if length(rest) >= 2
                bandId = str2double(rest(1));
                suf    = rest(end);
                isPre  = (suf == '0');
            end
        else
            % J/P + cyfra(y) pasma
            bandId = str2double(rest);
        end
    else
        % Pasma 7..10: nazwa zawiera polaryzację
        if typeChar == 'T'
            % np. TV70 -> band 7, suffix 0; TV101 -> band 10, suffix 1; TH80 -> band 8
            % Ostatnia cyfra to suffix (0/1), wcześniejsze to bandId.
            if length(rest) >= 2
                bandStr = rest(1:end-1);
                suf     = rest(end);
                bandId  = str2double(bandStr);
                isPre   = (suf == '0');
            end
        else
            % JV7, PH10 - bez sufiksu
            bandId = str2double(rest);
        end
    end

    if ~isfinite(bandId) || bandId < 3 || bandId > 10
        return;
    end

    % Zbuduj nazwę pola docelowego w strukturze pasma
    polSuffix = '';
    if polChar == 'V'
        polSuffix = 'V';
    elseif polChar == 'H'
        polSuffix = 'H';
    end

    targetField = '';
    switch typeChar
        case 'J'
            if endsB
                targetField = ['hamowanie' polSuffix];
            else
                targetField = ['jazda' polSuffix];
            end
        case 'P'
            % Postój - z definicji QP, ale plik nie musi mieć Q (akceptujemy oba)
            targetField = ['postoj' polSuffix];
        case 'T'
            % Tło: przed/po + ewentualnie polaryzacja + ewentualnie QP
            if isPre
                base = 'tloPrzed';
            else
                base = 'tloPo';
            end
            % Suffix: dla bez polaryzacji -> 'QP' (gdy QP)
            % Dla z polaryzacją -> 'HQ' / 'VQ'
            if isempty(polSuffix)
                if endsQ
                    targetField = [base 'QP'];
                else
                    targetField = base;  % tloPrzed / tloPo
                end
            else
                if endsQ
                    targetField = [base polSuffix 'Q'];
                else
                    targetField = [base polSuffix];
                end
            end
        otherwise
            return;
    end

    if isempty(targetField)
        return;
    end

    info = struct();
    info.bandId      = bandId;
    info.targetField = targetField;
end
