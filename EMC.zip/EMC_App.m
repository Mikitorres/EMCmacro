function EMC_App()
%EMC_APP Aplikacja do analizy badań EMC przewodzonych wg PN-EN 50121.
%
%   Uruchom z poziomu MATLAB poleceniem:
%       >> EMC_App
%
%   Aplikacja:
%     1) Pozwala wybrać folder z plikami pomiarowymi (format R&S ESPI,
%        nazwy plików zgodne z DOCX: J3..J10, T30..T101, P3Q..PH10Q itd.).
%     2) Pozwala wybrać wariant limitu wg PN-EN 50121
%        (B - kolejowy [domyślnie], C, Tramwaj, Wagon).
%     3) Wczytuje wszystkie rozpoznane pliki, oblicza limity wg normy
%        i pokazuje 9 wykresów porównawczych w skali logarytmicznej:
%           Wiersz 1 - pole H: postój, rozruch, hamowanie
%           Wiersz 2 - pole E (V): postój, rozruch, hamowanie
%           Wiersz 3 - pole E (H): postój, rozruch, hamowanie
%
%   Wymagane pliki w tym samym folderze co EMC_App.m:
%       readESPI.m, getBands.m, computeLimit.m,
%       loadMeasurementFolder.m, plotEMCResults.m

    % Stan aplikacji
    state = struct();
    state.folder  = '';
    state.variant = 'B';
    state.dataset = [];

    % Główne okno
    f = uifigure('Name', 'EMC PN-EN 50121 - Analiza pomiarów', ...
                 'Position', [200 200 720 420]);
    f.Resize = 'off';

    % Panel z parametrami
    pnl = uipanel(f, 'Position', [20 220 680 180], ...
                  'Title', 'Parametry analizy', 'FontWeight', 'bold');

    % --- Folder ---
    uilabel(pnl, 'Position', [15 130 80 22], 'Text', 'Folder:');
    edFolder = uieditfield(pnl, 'text', 'Position', [100 130 470 24], ...
                           'Editable', 'off', ...
                           'Placeholder', 'Wybierz folder z plikami pomiarowymi...');
    uibutton(pnl, 'push', 'Position', [580 130 85 24], ...
             'Text', 'Przeglądaj...', ...
             'ButtonPushedFcn', @(~,~) onSelectFolder());

    % --- Wariant limitu ---
    uilabel(pnl, 'Position', [15 90 110 22], 'Text', 'Wariant limitu:');
    ddVariant = uidropdown(pnl, 'Position', [125 90 140 24], ...
                           'Items', {'B (kolejowy)', 'C', 'Tramwaj', 'Wagon'}, ...
                           'Value', 'B (kolejowy)', ...
                           'ValueChangedFcn', @(src,~) onVariantChanged(src));

    % --- Status ---
    lblStatus = uilabel(pnl, 'Position', [15 20 660 60], ...
                        'Text', 'Status: gotowe. Wybierz folder z plikami pomiarowymi.', ...
                        'WordWrap', 'on', 'VerticalAlignment', 'top');

    % Dolny panel z przyciskami akcji
    btnPanel = uipanel(f, 'Position', [20 20 680 190], ...
                       'Title', 'Akcje', 'FontWeight', 'bold');

    btnLoad = uibutton(btnPanel, 'push', 'Position', [20 100 200 50], ...
             'Text', 'Wczytaj pliki', 'FontWeight', 'bold', ...
             'ButtonPushedFcn', @(~,~) onLoad(), 'Enable', 'off');

    btnPlot = uibutton(btnPanel, 'push', 'Position', [240 100 200 50], ...
             'Text', 'Generuj 9 wykresów', 'FontWeight', 'bold', ...
             'ButtonPushedFcn', @(~,~) onPlot(), 'Enable', 'off');

    btnExport = uibutton(btnPanel, 'push', 'Position', [460 100 200 50], ...
             'Text', 'Eksportuj raport (PDF)', ...
             'ButtonPushedFcn', @(~,~) onExport(), 'Enable', 'off');

    % Tekst pomocy
    helpText = sprintf(['Konwencja nazw plików (z DOCX, sekcja "Tabela z wynikami"):\n' ...
                        '  T = tło,  P = postój,  J = jazda,  B = hamowanie\n' ...
                        '  V = antena pionowa (E),  H = antena pozioma (E),  Q = detektor QuasiPeak\n' ...
                        '  Cyfry pasma: 3..10  (3=0,15-1,15 MHz ... 10=500-1000 MHz)\n' ...
                        '  Przykłady:  J3 (rozruch),  J3B (hamowanie),  P3Q (postój QP),  T30 (tło przed),  T31 (tło po)']);
    uilabel(btnPanel, 'Position', [20 10 660 80], 'Text', helpText, ...
            'VerticalAlignment', 'top', 'FontName', 'monospaced', 'FontSize', 10);

    % ---- Callbacki ----

    function onSelectFolder()
        sel = uigetdir(pwd, 'Wybierz folder z plikami pomiarowymi');
        if isequal(sel, 0); return; end
        state.folder = sel;
        edFolder.Value = sel;
        btnLoad.Enable = 'on';
        btnPlot.Enable = 'off';
        btnExport.Enable = 'off';
        lblStatus.Text = sprintf('Folder wybrany: %s\nKliknij "Wczytaj pliki" aby kontynuować.', sel);
        % uifigure traci focus po uigetdir - przywróć go
        figure(f);
    end

    function onVariantChanged(src)
        v = src.Value;
        if startsWith(v, 'B')
            state.variant = 'B';
        elseif startsWith(v, 'C')
            state.variant = 'C';
        elseif strcmpi(v, 'Tramwaj')
            state.variant = 'Tramwaj';
        else
            state.variant = 'Wagon';
        end
    end

    function onLoad()
        if isempty(state.folder); return; end
        lblStatus.Text = 'Wczytywanie plików - proszę czekać...';
        drawnow;
        try
            ds = loadMeasurementFolder(state.folder);
        catch ME
            lblStatus.Text = sprintf('Błąd wczytywania: %s', ME.message);
            uialert(f, ME.message, 'Błąd wczytywania');
            return;
        end
        state.dataset = ds;
        nFound   = numel(ds.filesFound);
        nSkipped = numel(ds.filesSkipped);
        msg = sprintf(['Wczytano %d plików (rozpoznanych) z folderu.\n' ...
                       'Pominięto %d plików (nieznana konwencja nazwy lub błąd odczytu).\n' ...
                       'Wybrany wariant limitu: %s.\n' ...
                       'Kliknij "Generuj 9 wykresów" aby wyświetlić wyniki.'], ...
                       nFound, nSkipped, state.variant);
        lblStatus.Text = msg;
        if nFound > 0
            btnPlot.Enable = 'on';
        else
            uialert(f, ['Nie rozpoznano żadnego pliku. Sprawdź czy nazwy plików ' ...
                        'są zgodne z konwencją (J3, T30, T31, P3Q, JV7, PH10Q itd.).'], ...
                    'Brak rozpoznanych plików');
        end
    end

    function onPlot()
        if isempty(state.dataset); return; end
        lblStatus.Text = 'Generowanie wykresów...';
        drawnow;
        try
            plotEMCResults(state.dataset, state.variant);
            btnExport.Enable = 'on';
            lblStatus.Text = sprintf('Wykresy wygenerowane (limit %s).', state.variant);
        catch ME
            lblStatus.Text = sprintf('Błąd generowania: %s', ME.message);
            uialert(f, ME.message, 'Błąd');
        end
    end

    function onExport()
        if isempty(state.dataset); return; end
        [fname, fpath] = uiputfile({'*.pdf', 'PDF (*.pdf)'; ...
                                    '*.png', 'PNG (*.png)'}, ...
                                   'Zapisz raport jako', ...
                                   sprintf('EMC_raport_%s.pdf', state.variant));
        if isequal(fname, 0); return; end
        try
            % Znajdź ostatnio otwarte okno z 9 wykresami (lub utwórz nowe)
            figs = findall(0, 'Type', 'figure', 'Name', ...
                           sprintf('EMC PN-EN 50121 - Wyniki (Limity %s)', state.variant));
            if isempty(figs)
                figs = plotEMCResults(state.dataset, state.variant);
            else
                figs = figs(1);
            end
            outFile = fullfile(fpath, fname);
            exportgraphics(figs, outFile, 'ContentType', 'vector', 'Resolution', 300);
            lblStatus.Text = sprintf('Raport zapisany: %s', outFile);
            figure(f);
        catch ME
            lblStatus.Text = sprintf('Błąd eksportu: %s', ME.message);
            uialert(f, ME.message, 'Błąd eksportu');
        end
    end

end
