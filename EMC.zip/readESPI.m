function data = readESPI(filepath)
%READESPI Wczytuje plik pomiarowy R&S ESPI (format CSV z separatorem ';').
%
%   data = readESPI(filepath) zwraca strukturę z polami:
%       freq        - wektor częstotliwości [Hz]
%       value       - wektor wartości pomiarowych [dB]
%       traceMode   - 'MAXHOLD' / 'CLRWRITE' / itp.
%       detector    - 'MAXPEAK' / 'QUASIPEAK' / itp.
%       yUnit       - jednostka osi Y (np. 'dBuA/m' lub 'dBuV/m')
%       startHz, stopHz - zakres pasma
%       nValues     - liczba punktów pomiarowych
%       header      - cała mapa metadanych (containers.Map)
%
%   Plik ma nagłówek z metadanymi (klucz;wartość;[jednostka]) zakończony
%   linią 'Values;N;', po której następuje N wierszy 'freq;value;'.

    if ~isfile(filepath)
        error('readESPI:fileNotFound', 'Plik nie istnieje: %s', filepath);
    end

    % Wczytaj cały plik jako tekst (kodowanie domyślnie - znaki specjalne
    % w nagłówku jak 'dB?A/m' z błędnym kodowaniem nas nie interesują)
    fid = fopen(filepath, 'r');
    if fid < 0
        error('readESPI:openFailed', 'Nie można otworzyć pliku: %s', filepath);
    end
    rawText = fread(fid, '*char')';
    fclose(fid);

    % Usuń \r, podziel na linie
    rawText = strrep(rawText, char(13), '');
    lines = strsplit(rawText, char(10));

    % Parsuj nagłówek do mapy
    header = containers.Map('KeyType', 'char', 'ValueType', 'char');
    valuesIdx = -1;
    nValues = 0;
    for i = 1:length(lines)
        line = lines{i};
        if isempty(line)
            continue;
        end
        parts = strsplit(line, ';');
        if isempty(parts)
            continue;
        end
        key = strtrim(parts{1});
        if strcmpi(key, 'Values')
            % Linia "Values;N;" - dane zaczynają się od następnej linii
            if length(parts) >= 2
                nValues = str2double(parts{2});
            end
            valuesIdx = i;
            header('Values') = parts{2};
            break;
        end
        % Klucze numeryczne (linie danych) ignoruj na tym etapie
        if ~isempty(key) && ~all(isstrprop(key, 'digit') | key=='.' | key=='-' | key=='+')
            if length(parts) >= 2
                header(key) = strtrim(parts{2});
            end
        end
    end

    if valuesIdx < 0 || nValues <= 0
        error('readESPI:badFormat', 'Nie znaleziono linii ''Values;N;'' w pliku %s', filepath);
    end

    % Wczytaj dane: linie od valuesIdx+1 do valuesIdx+nValues
    freq = zeros(nValues, 1);
    val  = zeros(nValues, 1);
    nGot = 0;
    for k = 1:nValues
        idx = valuesIdx + k;
        if idx > length(lines)
            break;
        end
        line = lines{idx};
        if isempty(line)
            continue;
        end
        parts = strsplit(line, ';');
        if length(parts) < 2
            continue;
        end
        f = str2double(parts{1});
        v = str2double(parts{2});
        if isfinite(f) && isfinite(v)
            nGot = nGot + 1;
            freq(nGot) = f;
            val(nGot)  = v;
        end
    end

    freq = freq(1:nGot);
    val  = val(1:nGot);

    data = struct();
    data.freq      = freq;        % Hz
    data.value     = val;         % dB
    data.nValues   = nGot;
    data.header    = header;
    data.traceMode = getOpt(header, 'Trace Mode', '');
    data.detector  = getOpt(header, 'Detector',   '');
    data.yUnit     = normalizeUnit(getOpt(header, 'y-Unit', ''));
    data.startHz   = str2double(getOpt(header, 'Start', 'NaN'));
    data.stopHz    = str2double(getOpt(header, 'Stop',  'NaN'));
end

function v = getOpt(map, key, default)
    if isKey(map, key)
        v = map(key);
    else
        v = default;
    end
end

function u = normalizeUnit(u)
    % Naprawia błędne kodowanie 'µ' (mikro). Plik ESPI często ma 'dB?A/m'
    % zamiast 'dBµA/m'. Standaryzujemy do ASCII 'dBuA/m' / 'dBuV/m'.
    u = regexprep(u, 'dB[^A-Za-z]?A/m', 'dBuA/m');
    u = regexprep(u, 'dB[^A-Za-z]?V/m', 'dBuV/m');
end
