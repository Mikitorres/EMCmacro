function fig = plotEMCResults(dataset, variant)
%PLOTEMCRESULTS Pokazuje wyniki badań EMC w postaci 9 wykresów,
%   po jednym na okno, z nawigacją klawiszami.
%
%   fig = plotEMCResults(dataset, variant)
%
%   Wejście:
%       dataset - wynik z loadMeasurementFolder
%       variant - wariant limitu ('B' / 'C' / 'Tramwaj' / 'Wagon'),
%                 domyślnie 'B'
%
%   Sterowanie klawiaturą (kliknij okno, żeby było aktywne):
%       Strzałka w prawo / Page Down / spacja / 'n' - następny wykres
%       Strzałka w lewo  / Page Up   / 'p' / Backspace - poprzedni wykres
%       Home / '1'                                  - pierwszy wykres
%       End                                         - ostatni wykres
%       's'                                         - zapis BIEŻĄCEGO
%                                                     wykresu (dialog
%                                                     wyboru pliku)
%       'a' (Shift+S)                               - zapis WSZYSTKICH 9
%                                                     wykresów do
%                                                     wybranego folderu
%       1..9                                        - skok do wykresu
%       'q' lub Esc                                 - zamknij okno
%
%   Układ 9 wykresów (skala logarytmiczna na osi f):
%       Wiersz 1 - pole H (pasma 3..6, antena pętlowa):
%           1) Postój (QP)        - vs limit postój H
%           2) Rozruch (MAXHOLD)  - vs limit jazda H
%           3) Hamowanie (MAXHOLD)- vs limit jazda H
%       Wiersz 2 - pole E polaryzacja V (pasma 7..10):
%           4) Postój, 5) Rozruch, 6) Hamowanie
%       Wiersz 3 - pole E polaryzacja H (pasma 7..10):
%           7) Postój, 8) Rozruch, 9) Hamowanie

    if nargin < 2 || isempty(variant)
        variant = 'B';
    end

    % Definicja 9 paneli: {tytuł, fieldType, condition, polaryzacja, pole-z-danymi}
    panels = {
      'H - Postój (QP)',         'H', 'postoj', '',  'postoj';
      'H - Rozruch (jazda)',     'H', 'jazda',  '',  'jazda';
      'H - Hamowanie',           'H', 'jazda',  '',  'hamowanie';
      'E V - Postój (QP)',       'E', 'postoj', 'V', 'postojV';
      'E V - Rozruch (jazda)',   'E', 'jazda',  'V', 'jazdaV';
      'E V - Hamowanie',         'E', 'jazda',  'V', 'hamowanieV';
      'E H - Postój (QP)',       'E', 'postoj', 'H', 'postojH';
      'E H - Rozruch (jazda)',   'E', 'jazda',  'H', 'jazdaH';
      'E H - Hamowanie',         'E', 'jazda',  'H', 'hamowanieH';
    };

    % Stan zapisany w UserData figury - dzięki temu callbacki klawiszy
    % mają dostęp do wszystkiego co potrzebne
    s = struct();
    s.dataset      = dataset;
    s.variant      = variant;
    s.panels       = panels;
    s.nPanels      = size(panels, 1);
    s.currentIdx   = 1;
    s.lastSaveDir  = '';   % zapamiętany folder zapisu

    fig = figure('Name', 'EMC PN-EN 50121 - Wyniki', ...
                 'Color', 'w', 'Position', [100 100 1100 700], ...
                 'NumberTitle', 'off', ...
                 'KeyPressFcn', @onKeyPress);
    fig.UserData = s;

    drawCurrent(fig);
end


function onKeyPress(src, event)
    s = src.UserData;
    key = event.Key;
    chr = '';
    if isfield(event, 'Character') && ~isempty(event.Character)
        chr = event.Character;
    end

    needRedraw = false;

    switch key
        case {'rightarrow', 'pagedown', 'space', 'n'}
            s.currentIdx = mod(s.currentIdx, s.nPanels) + 1;
            needRedraw = true;

        case {'leftarrow', 'pageup', 'p', 'backspace'}
            s.currentIdx = mod(s.currentIdx - 2, s.nPanels) + 1;
            needRedraw = true;

        case {'home', '1'}
            s.currentIdx = 1;
            needRedraw = true;

        case 'end'
            s.currentIdx = s.nPanels;
            needRedraw = true;

        case {'q', 'escape'}
            close(src);
            return;

        case 's'
            % 's' = zapis bieżącego wykresu
            saveCurrent(src);
            return;

        case 'a'
            % 'a' = zapis wszystkich 9 wykresów do wybranego folderu
            saveAll(src);
            return;

        otherwise
            % Cyfry 2..9 dla szybkiego przeskoku do wykresu nr N
            if ~isempty(chr) && length(chr) == 1 && chr >= '2' && chr <= '9'
                idx = chr - '0';
                if idx >= 1 && idx <= s.nPanels
                    s.currentIdx = idx;
                    needRedraw = true;
                end
            end
    end

    if needRedraw
        src.UserData = s;
        drawCurrent(src);
    end
end


function drawCurrent(fig)
    s = fig.UserData;
    clf(fig);

    % KeyPressFcn bywa zerowane przez clf - przywróć
    fig.KeyPressFcn = @onKeyPress;

    % Główny obszar wykresu - zostaw miejsce na pasek instrukcji na dole
    ax = axes('Parent', fig, 'Position', [0.09 0.16 0.86 0.74]);

    panelDef = s.panels(s.currentIdx, :);
    plotPanel(ax, s.dataset, s.variant, panelDef);

    % Tytuł okna
    fig.Name = sprintf('EMC PN-EN 50121 - [%d/%d] - %s (Limity %s)', ...
                      s.currentIdx, s.nPanels, panelDef{1}, s.variant);

    % Pasek instrukcji na dole
    annotation(fig, 'textbox', [0 0.01 1 0.06], ...
        'String', ['Sterowanie:  \leftarrow / \rightarrow  - przełączanie wykresów   |   ' ...
                   's - zapis bieżącego   |   a - zapis wszystkich 9   |   ' ...
                   '1..9 - skok do wykresu   |   q - zamknij'], ...
        'EdgeColor', 'none', ...
        'HorizontalAlignment', 'center', ...
        'VerticalAlignment', 'middle', ...
        'FontSize', 10, ...
        'Color', [0.3 0.3 0.3]);

    % Wskaźnik strony w prawym górnym rogu
    annotation(fig, 'textbox', [0.83 0.93 0.15 0.05], ...
        'String', sprintf('Wykres %d / %d', s.currentIdx, s.nPanels), ...
        'EdgeColor', 'none', ...
        'HorizontalAlignment', 'right', ...
        'FontSize', 11, 'FontWeight', 'bold', ...
        'Color', [0.2 0.2 0.6]);
end


function saveCurrent(fig)
%SAVECURRENT Zapisuje bieżący wykres do pliku - dialog wyboru lokalizacji.
    s = fig.UserData;
    panelDef = s.panels(s.currentIdx, :);

    % Folder startowy: zapamiętany lub bieżący katalog
    startDir = pwd;
    if ~isempty(s.lastSaveDir) && isfolder(s.lastSaveDir)
        startDir = s.lastSaveDir;
    end

    defaultName = sprintf('EMC_%s_wykres%d_%s.png', ...
                          s.variant, s.currentIdx, ...
                          sanitizeFileName(panelDef{1}));
    [fname, fpath] = uiputfile( ...
        {'*.png', 'PNG (*.png)';
         '*.pdf', 'PDF (*.pdf)';
         '*.jpg', 'JPEG (*.jpg)';
         '*.tif', 'TIFF (*.tif)';
         '*.fig', 'MATLAB Figure (*.fig)'}, ...
        sprintf('Zapis wykresu %d/%d', s.currentIdx, s.nPanels), ...
        fullfile(startDir, defaultName));

    if isequal(fname, 0); return; end
    outFile = fullfile(fpath, fname);

    try
        saveOneFigure(fig, outFile);
        s.lastSaveDir = fpath;
        fig.UserData  = s;
        fprintf('Zapisano: %s\n', outFile);
    catch ME
        warndlg(sprintf('Błąd zapisu: %s', ME.message), 'Zapis nieudany');
    end
end


function saveAll(fig)
%SAVEALL Zapisuje wszystkie 9 wykresów do wybranego folderu.
    s = fig.UserData;

    startDir = pwd;
    if ~isempty(s.lastSaveDir) && isfolder(s.lastSaveDir)
        startDir = s.lastSaveDir;
    end
    folder = uigetdir(startDir, 'Wybierz folder zapisu (9 plików PNG)');
    if isequal(folder, 0); return; end

    s.lastSaveDir = folder;
    origIdx = s.currentIdx;

    saved = 0;
    failed = {};
    for k = 1:s.nPanels
        s.currentIdx = k;
        fig.UserData = s;
        drawCurrent(fig);
        drawnow;

        panelDef = s.panels(k, :);
        outFile = fullfile(folder, sprintf('EMC_%s_wykres%d_%s.png', ...
                           s.variant, k, sanitizeFileName(panelDef{1})));
        try
            saveOneFigure(fig, outFile);
            saved = saved + 1;
        catch ME
            failed{end+1} = sprintf('  %s: %s', outFile, ME.message); %#ok<AGROW>
        end
    end

    % Wróć do panelu wyjściowego
    s.currentIdx = origIdx;
    fig.UserData = s;
    drawCurrent(fig);

    msg = sprintf('Zapisano %d / %d wykresów do:\n%s', saved, s.nPanels, folder);
    if ~isempty(failed)
        msg = [msg sprintf('\n\nBłędy:\n%s', strjoin(failed, newline))];
    end
    msgbox(msg, 'Zapis wszystkich wykresów');
end


function saveOneFigure(fig, outFile)
%SAVEONEFIGURE Zapisuje bieżącą zawartość okna do pliku graficznego.
    [~,~,ext] = fileparts(outFile);
    ext = lower(ext);
    switch ext
        case '.fig'
            savefig(fig, outFile);
        case {'.pdf', '.eps'}
            exportgraphics(fig, outFile, 'ContentType', 'vector', ...
                           'BackgroundColor', 'white');
        otherwise
            % PNG/JPG/TIF - eksport rastrowy
            exportgraphics(fig, outFile, 'Resolution', 300, ...
                           'BackgroundColor', 'white');
    end
end


function name = sanitizeFileName(name)
%SANITIZEFILENAME Usuwa znaki niedozwolone w nazwach plików i polskie znaki.
    name = regexprep(name, '[\\/:*?"<>|]', '_');
    name = regexprep(name, '\s+', '_');
    name = regexprep(name, '[\(\)]', '');
    pl = {'ó','Ó','ą','Ą','ę','Ę','ł','Ł','ń','Ń','ś','Ś','ż','Ż','ź','Ź','ć','Ć'};
    en = {'o','O','a','A','e','E','l','L','n','N','s','S','z','Z','z','Z','c','C'};
    for k = 1:numel(pl)
        name = strrep(name, pl{k}, en{k});
    end
end


% =====================================================================
% Funkcja rysująca pojedynczy panel - zajmuje całe okno
% =====================================================================
function plotPanel(ax, dataset, variant, panelDef)
    panelTitle  = panelDef{1};
    fieldType   = panelDef{2};
    condition   = panelDef{3};
    polChar     = panelDef{4};
    measField   = panelDef{5};

    hold(ax, 'on');
    set(ax, 'XScale', 'log');
    grid(ax, 'on');
    box(ax, 'on');

    if fieldType == 'H'
        bandIds = [3, 4, 5, 6];
    else
        bandIds = [7, 8, 9, 10];
    end

    colMeas      = [0.85 0.10 0.10];
    colTloPrzed  = [0.30 0.30 0.30];
    colTloPo     = [0.55 0.55 0.55];
    colLimit     = [0.10 0.40 0.85];

    allFreqMeas    = [];
    allValMeas     = [];
    allFreqTloPrzed = [];
    allValTloPrzed  = [];
    allFreqTloPo    = [];
    allValTloPo     = [];

    isQP = strcmp(condition, 'postoj');

    for bid = bandIds
        bIdx = find([dataset.bands.id] == bid, 1);
        if isempty(bIdx); continue; end
        b = dataset.bands(bIdx);

        meas = getFieldSafe(b, measField);
        if ~isempty(meas)
            allFreqMeas = [allFreqMeas; meas.freq]; %#ok<AGROW>
            allValMeas  = [allValMeas;  meas.value]; %#ok<AGROW>
        end

        if isempty(polChar)
            if isQP
                tPrzedField = 'tloPrzedQP';
                tPoField    = 'tloPoQP';
            else
                tPrzedField = 'tloPrzed';
                tPoField    = 'tloPo';
            end
        else
            if isQP
                tPrzedField = ['tloPrzed' polChar 'Q'];
                tPoField    = ['tloPo'    polChar 'Q'];
            else
                tPrzedField = ['tloPrzed' polChar];
                tPoField    = ['tloPo'    polChar];
            end
        end

        tPrzed = getFieldSafe(b, tPrzedField);
        if ~isempty(tPrzed)
            allFreqTloPrzed = [allFreqTloPrzed; tPrzed.freq]; %#ok<AGROW>
            allValTloPrzed  = [allValTloPrzed;  tPrzed.value]; %#ok<AGROW>
        end
        tPo = getFieldSafe(b, tPoField);
        if ~isempty(tPo)
            allFreqTloPo = [allFreqTloPo; tPo.freq]; %#ok<AGROW>
            allValTloPo  = [allValTloPo;  tPo.value]; %#ok<AGROW>
        end
    end

    [allFreqMeas, oM]      = sort(allFreqMeas);
    allValMeas             = allValMeas(oM);
    [allFreqTloPrzed, oT1] = sort(allFreqTloPrzed);
    allValTloPrzed         = allValTloPrzed(oT1);
    [allFreqTloPo, oT2]    = sort(allFreqTloPo);
    allValTloPo            = allValTloPo(oT2);

    legendHandles = gobjects(0);
    legendNames   = {};

    if ~isempty(allFreqTloPrzed)
        h = plot(ax, allFreqTloPrzed/1e3, allValTloPrzed, '-', ...
                 'Color', colTloPrzed, 'LineWidth', 0.8);
        legendHandles(end+1) = h; legendNames{end+1} = 'Tło przed';
    end
    if ~isempty(allFreqTloPo)
        h = plot(ax, allFreqTloPo/1e3, allValTloPo, '-', ...
                 'Color', colTloPo, 'LineWidth', 0.8);
        legendHandles(end+1) = h; legendNames{end+1} = 'Tło po';
    end

    if ~isempty(allFreqMeas)
        h = plot(ax, allFreqMeas/1e3, allValMeas, '-', ...
                 'Color', colMeas, 'LineWidth', 1.4);
        legendHandles(end+1) = h; legendNames{end+1} = sprintfMeasLabel(measField, isQP);
    end

    fStart = min([dataset.bands(ismember([dataset.bands.id],bandIds)).fStartHz]);
    fStop  = max([dataset.bands(ismember([dataset.bands.id],bandIds)).fStopHz]);
    if isfinite(fStart) && isfinite(fStop) && fStop > fStart
        fLim   = logspace(log10(fStart), log10(fStop), 1000);
        limDb  = computeLimit(fLim, fieldType, condition, variant);
        h = plot(ax, fLim/1e3, limDb, '--', ...
                 'Color', colLimit, 'LineWidth', 2.0);
        legendHandles(end+1) = h;
        legendNames{end+1}   = sprintf('Limit %s (%s)', variant, condition);
    end

    % --- ZNACZNIKI PRZEKROCZEŃ (na stałej wysokości u góry osi Y) ---
    %
    % Reguły oceny dla każdej częstotliwości pomiaru:
    %   1. Jeśli tło (przed LUB po) przekracza limit -> BRĄZOWY kwadrat
    %      (badanie nie nadaje się do oceny, do powtórki - tło zasłania).
    %   2. W przeciwnym razie, jeśli pomiar przekracza limit -> CZERWONY
    %      kwadrat (rzeczywiste przekroczenie poziomu emisji EUT).
    %   3. W przeciwnym razie - brak znacznika (zgodne z normą).
    if ~isempty(allFreqMeas)
        [exFreqRed, exFreqBrown] = detectExceedances( ...
            allFreqMeas, allValMeas, ...
            allFreqTloPrzed, allValTloPrzed, ...
            allFreqTloPo, allValTloPo, ...
            fieldType, condition, variant);

        % Wysokość markerów - 95% zakresu osi Y (stała pozycja u góry)
        yLimAxis = ylim(ax);
        yMarker  = yLimAxis(1) + 0.95 * (yLimAxis(2) - yLimAxis(1));

        % Brązowy kwadrat - tło przekracza (rysowany pierwszy, żeby
        % czerwone leżały na wierzchu gdy się pokrywają)
        if ~isempty(exFreqBrown)
            h = plot(ax, exFreqBrown/1e3, ...
                     yMarker * ones(size(exFreqBrown)), ...
                     's', 'MarkerSize', 7, ...
                     'MarkerEdgeColor', [0.45 0.25 0.10], ...
                     'MarkerFaceColor', [0.65 0.40 0.20], ...
                     'LineStyle', 'none');
            legendHandles(end+1) = h;
            legendNames{end+1}   = 'Tło > limit (do powtórki)';
        end

        % Czerwony kwadrat - rzeczywiste przekroczenie pomiaru
        if ~isempty(exFreqRed)
            h = plot(ax, exFreqRed/1e3, ...
                     yMarker * ones(size(exFreqRed)), ...
                     's', 'MarkerSize', 7, ...
                     'MarkerEdgeColor', [0.55 0 0], ...
                     'MarkerFaceColor', [0.95 0.10 0.10], ...
                     'LineStyle', 'none');
            legendHandles(end+1) = h;
            legendNames{end+1}   = 'Pomiar > limit';
        end

        % Komunikat informacyjny w lewym górnym rogu
        nRed   = numel(exFreqRed);
        nBrown = numel(exFreqBrown);
        statusStr = sprintf('Przekroczenia:  pomiar = %d  |  tło = %d', nRed, nBrown);
        text(ax, 0.02, 0.97, statusStr, ...
             'Units', 'normalized', ...
             'HorizontalAlignment', 'left', ...
             'VerticalAlignment', 'top', ...
             'FontSize', 9, 'FontWeight', 'bold', ...
             'BackgroundColor', [1 1 1 0.7], ...
             'EdgeColor', [0.6 0.6 0.6]);
    end

    xlabel(ax, 'Częstotliwość f [kHz]', 'FontSize', 11);
    if fieldType == 'H'
        ylabel(ax, 'H [dB\muA/m]', 'FontSize', 11);
    else
        ylabel(ax, 'E [dB\muV/m]', 'FontSize', 11);
    end
    title(ax, panelTitle, 'FontWeight', 'bold', 'FontSize', 13);

    if ~isempty(legendHandles)
        legend(ax, legendHandles, legendNames, ...
               'Location', 'best', 'FontSize', 10);
    end

    if isfinite(fStart) && isfinite(fStop) && fStop > fStart
        xlim(ax, [fStart, fStop]/1e3);
    end
    hold(ax, 'off');
end


function [exFreqRed, exFreqBrown] = detectExceedances( ...
        fMeas, vMeas, fTloPrzed, vTloPrzed, fTloPo, vTloPo, ...
        fieldType, condition, variant)
%DETECTEXCEEDANCES Wykrywa częstotliwości, w których wystąpiło przekroczenie.
%
%   Logika:
%     - tło (przed LUB po) > limit  -> brązowy (badanie do powtórki)
%     - inaczej, gdy pomiar > limit -> czerwony (rzeczywiste przekroczenie)
%
%   Każda lista zwracana zawiera unikalne częstotliwości (Hz), posortowane
%   rosnąco. Próbki sąsiednie są łączone w grupy o oddzielonych odstępach -
%   żeby uniknąć wizualnego "zalewu" markerów przy gęstych przekroczeniach.

    exFreqRed   = [];
    exFreqBrown = [];

    if isempty(fMeas) || isempty(vMeas)
        return;
    end

    % Limit na częstotliwościach pomiaru (potrzebny do porównania)
    limMeas = computeLimit(fMeas, fieldType, condition, variant);
    valid   = isfinite(limMeas);
    if ~any(valid)
        return;
    end

    % --- Sprawdzenie tła ---
    % Tło może być zmierzone w innych punktach niż pomiar - interpolujemy
    % tło na siatkę pomiaru, biorąc maksimum z tła "przed" i "po".
    bgAtMeas = -inf(size(fMeas));
    if ~isempty(fTloPrzed) && ~isempty(vTloPrzed)
        bgAtMeas = max(bgAtMeas, interp1(fTloPrzed, vTloPrzed, fMeas, ...
                                        'linear', NaN));
    end
    if ~isempty(fTloPo) && ~isempty(vTloPo)
        bgPo = interp1(fTloPo, vTloPo, fMeas, 'linear', NaN);
        bgAtMeas = max(bgAtMeas, bgPo);
    end
    % NaN przy interp -> brak tła; traktujemy jak -Inf (czyli "tło ok")
    bgAtMeas(~isfinite(bgAtMeas)) = -Inf;

    % --- Decyzja per próbka ---
    bgExceeds   = valid & (bgAtMeas > limMeas);
    measExceeds = valid & (vMeas    > limMeas);

    isBrown = bgExceeds;                   % priorytet: brązowy zawsze gdy tło > limit
    isRed   = measExceeds & ~bgExceeds;    % czerwony tylko gdy pomiar > limit i tło ok

    fRedSamples   = fMeas(isRed);
    fBrownSamples = fMeas(isBrown);

    % Grupowanie sąsiednich próbek - jedna kropka na "ciągły" zakres
    exFreqRed   = groupAdjacent(fRedSamples);
    exFreqBrown = groupAdjacent(fBrownSamples);
end


function fOut = groupAdjacent(fIn)
%GROUPADJACENT Łączy ciągłe pasma próbek w pojedyncze punkty (środek zakresu).
%   Dzięki temu zamiast 50 nakładających się markerów na ciągłym
%   przekroczeniu mamy 1 marker w środku tego pasma.

    fOut = [];
    if isempty(fIn); return; end
    fIn = sort(fIn(:));

    % Próg "ciągłości" - dwie próbki traktowane jako sąsiednie, jeśli
    % różnica względna < 1% (skala log)
    if length(fIn) == 1
        fOut = fIn;
        return;
    end

    df = diff(fIn);
    medStep = median(df);
    if medStep <= 0; medStep = 1; end
    breaks = find(df > 5 * medStep);   % > 5x typowy krok = nowa grupa

    groupStartIdx = [1; breaks + 1];
    groupEndIdx   = [breaks; length(fIn)];

    fOut = zeros(numel(groupStartIdx), 1);
    for k = 1:numel(groupStartIdx)
        % Punkt środkowy grupy w skali log
        a = log10(fIn(groupStartIdx(k)));
        b = log10(fIn(groupEndIdx(k)));
        fOut(k) = 10^((a + b) / 2);
    end
end


% =====================================================================
% Funkcje pomocnicze
% =====================================================================
function v = getFieldSafe(s, fname)
    v = [];
    if isfield(s, fname) && ~isempty(s.(fname))
        v = s.(fname);
    end
end


function lbl = sprintfMeasLabel(fieldName, isQP)
    base = lower(fieldName);
    base = regexprep(base, '[vh]$', '');
    switch base
        case 'jazda';     lbl = 'Rozruch (MAXHOLD)';
        case 'hamowanie'; lbl = 'Hamowanie (MAXHOLD)';
        case 'postoj'
            if isQP
                lbl = 'Postój (QP)';
            else
                lbl = 'Postój';
            end
        otherwise
            lbl = fieldName;
    end
end
