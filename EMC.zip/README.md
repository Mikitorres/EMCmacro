# EMC_App – Aplikacja MATLAB do analizy badań EMC wg PN-EN 50121

Aplikacja wczytuje serię plików pomiarowych z odbiornika R&S ESPI, porównuje
je z limitami z normy **PN-EN 50121-3-1** i prezentuje wyniki w postaci 9
wykresów w skali logarytmicznej – **po jednym na okno, z nawigacją
klawiaturową**.

## Zawartość paczki

| Plik | Opis |
|------|------|
| `EMC_App.m` | Aplikacja z GUI – uruchom z poziomu MATLAB |
| `readESPI.m` | Wczytuje pojedynczy plik ESPI (CSV z separatorem `;`) |
| `getBands.m` | Definicje 8 pasm pomiarowych (3..10) |
| `computeLimit.m` | Limity z normy (B / C / Tramwaj / Wagon) – interpolacja log-liniowa |
| `loadMeasurementFolder.m` | Skanuje folder, rozpoznaje konwencję nazw, wczytuje wszystko |
| `plotEMCResults.m` | Generuje 9 wykresów (jeden na okno) z nawigacją |

## Uruchomienie

1. Skopiuj wszystkie pliki `.m` do jednego folderu.
2. W MATLAB ustaw ten folder jako bieżący lub dodaj do ścieżki:
   ```matlab
   addpath('C:\sciezka\do\folderu\z\plikami_m')
   ```
3. Uruchom aplikację:
   ```matlab
   EMC_App
   ```
4. W oknie aplikacji:
   - Kliknij **Przeglądaj…** i wybierz folder zawierający pliki pomiarowe
   - Wybierz wariant limitu (domyślnie **B – kolejowy**)
   - Kliknij **Wczytaj pliki**
   - Kliknij **Generuj 9 wykresów** – pojawi się okno z pierwszym wykresem

## Sterowanie oknem wykresów

**Kliknij okno wykresu, żeby było aktywne dla klawiatury**, następnie:

| Klawisz | Akcja |
|---------|-------|
| **→** *(strzałka w prawo)* | Następny wykres (po 9 wraca do 1) |
| **←** *(strzałka w lewo)* | Poprzedni wykres (przed 1 idzie do 9) |
| **PgDn** / **Spacja** / **n** | Następny wykres |
| **PgUp** / **p** / **Backspace** | Poprzedni wykres |
| **Home** / **1** | Pierwszy wykres |
| **End** | Ostatni wykres |
| **2..9** | Skok bezpośredni do wykresu o numerze |
| **s** | **Zapis bieżącego wykresu** – dialog wyboru pliku (PNG/PDF/JPG/TIF/FIG) |
| **a** | Zapis WSZYSTKICH 9 wykresów – dialog wyboru folderu, pliki PNG |
| **q** / **Esc** | Zamknięcie okna |

Po pierwszym zapisie aplikacja zapamiętuje folder docelowy – kolejne
wywołania `s` pojawią się od razu w tym samym katalogu (można zmienić
w dialogu).

## Konwencja nazw plików (wg DOCX *EMC_tabele_wyniki…*)

| Litera | Znaczenie |
|--------|-----------|
| `T` | tło |
| `P` | postój |
| `J` | jazda (rozruch) |
| `B` (na końcu, po J) | hamowanie |
| `V` | antena pionowa (pole E, pasma 7..10) |
| `H` | antena pozioma (pole E, pasma 7..10) |
| `Q` (na końcu) | detektor QuasiPeak |

| Cyfra pasma | Zakres f | Antena |
|-------------|----------|--------|
| `3` | 0,15 – 1,15 MHz | HFH2-Z2 (pętlowa, pole H) |
| `4` | 1 – 11 MHz | HFH2-Z2 |
| `5` | 10 – 20 MHz | HFH2-Z2 |
| `6` | 20 – 30 MHz | HFH2-Z2 |
| `7` | 30 – 230 MHz | HK116 (V/H) |
| `8` | 200 – 300 MHz | HK116 (V/H) |
| `9` | 300 – 500 MHz | HL223 (V/H) |
| `10` | 500 – 1000 MHz | HL223 (V/H) |

### Przykładowe nazwy plików

- `J3` – jazda (rozruch), pasmo 3, MAXHOLD/MAXPEAK
- `J3B` – hamowanie, pasmo 3, MAXHOLD
- `P3Q` – postój, pasmo 3, QuasiPeak
- `T30` / `T31` – tło **przed** / **po** rozruchem, pasmo 3
- `T30Q` / `T31Q` – tła do postoju (QP)
- `JV7` / `JH7` – rozruch, pasmo 7, antena V / H
- `JV7B` / `JH7B` – hamowanie, pasmo 7, V / H
- `PV7Q` / `PH7Q` – postój QP, pasmo 7, V / H
- `TV70` / `TV71` – tło przed/po, pasmo 7, antena V (do MAXHOLD)
- `TV70Q` / `TV71Q` – tła QP, pasmo 7, antena V

## Układ 9 wykresów

|  | Postój (QP) | Rozruch (MAXHOLD) | Hamowanie (MAXHOLD) |
|--|-------------|-------------------|---------------------|
| **Pole H** (3..6) | 1 | 2 | 3 |
| **Pole E – pol. V** (7..10) | 4 | 5 | 6 |
| **Pole E – pol. H** (7..10) | 7 | 8 | 9 |

Każdy panel:
- oś X: częstotliwość [kHz] w skali **log**
- oś Y: poziom [dBµA/m] dla H lub [dBµV/m] dla E
- czerwona krzywa: wynik pomiaru
- szare krzywe: tła (przed i po) dla weryfikacji
- niebieska przerywana: limit z normy (dla wybranego wariantu i warunku)

### Znaczniki przekroczeń (kwadraty u góry osi Y)

Aplikacja automatycznie wykrywa i oznacza przekroczenia limitu:

| Symbol | Kiedy się pojawia | Znaczenie |
|--------|-------------------|-----------|
| 🟥 **Czerwony kwadrat** | Pomiar > limit i tło ≤ limit | Rzeczywiste przekroczenie poziomu emisji EUT - wymaga uwagi |
| 🟫 **Brązowy kwadrat** | Tło (przed lub po) > limit | Tło zasłania pomiar - badanie do powtórki / pomiar wykluczony z oceny |

**Logika oceny (zgodnie z normą):**
- Brązowy ma **priorytet** nad czerwonym - jeśli tło przekracza limit, znacznik jest brązowy niezależnie od pomiaru (pomiaru i tak nie da się ocenić w tym punkcie)
- Czerwony pojawia się tylko wtedy, gdy pomiar przekracza limit, a żadne z teł go nie przekracza

W lewym górnym rogu panelu wyświetlana jest informacja zbiorcza
"Przekroczenia: pomiar = N | tło = M".

Sąsiednie próbki przekraczające limit są łączone w grupy - ciągłe pasmo
przekroczeń pokazywane jest jako pojedynczy znacznik w środku tego pasma
(zapobiega zalewowi markerów przy szerokopasmowych zaburzeniach).

## Wymagania

- **MATLAB R2018b** lub nowszy (potrzebne `uifigure`, `exportgraphics`)
- Brak dodatkowych toolboxów

## Uwagi techniczne

- Niepewności pomiarowe nie są uwzględniane (zgodnie z założeniami projektu)
- Aplikacja nie modyfikuje oryginalnych plików pomiarowych
- Pliki, których nazwa nie pasuje do konwencji, są ignorowane (lista
  pominiętych dostępna w polu `dataset.filesSkipped`)
- Wartości limitów pochodzą z arkusza `Limits` w pliku
  `EMC_MAKRO_WZOR_wer_16_PL.xlsm` i są interpolowane liniowo na osi
  log10(f) zgodnie z formułą `limit(f) = a·log10(f_kHz) + b`
